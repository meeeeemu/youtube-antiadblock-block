# youtube-adblock-bypass

i got the fabled "Adblockers are not allowed on youtube" message the other day which disabled video playback on youtube

this extension gets the video url and changes it to an embed, since video embeds dont get the adblocker message thing

enjoy :>

# TO-DO:

fix playlists (it will happen)

probably make it more i guess compatible with stuff lol

**NOTE: this will disable a few features on the video player and you may find some videos are unable to be played due to copyright but hey it's better than wasting your time by sitting through ads**

## installation

https://addons.mozilla.org/en-GB/firefox/addon/youtube-anti-adblock-bypasser/
