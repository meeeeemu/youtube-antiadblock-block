# youtube-adblock-block

i got the fabled "Adblockers are not allowed on youtube" message the other day which disabled video playback on youtube

this extension gets the video url and changes it to an embed, since video embeds dont get the adblocker message thing

enjoy :>

#### NOTE: this will disable a few features on the video player and you may find some videos are unable to be played due to copyright but hey it's better than wasting your time by sitting through ads